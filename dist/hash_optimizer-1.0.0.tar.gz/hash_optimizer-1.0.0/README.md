# 优化的跨进程一致性哈希函数库

一个高性能、跨进程一致的哈希计算库，解决了Python内置`hash()`函数的局限性。

## 特性

- 🚀 **高性能**: 使用栈迭代替代递归，避免深度限制
- 🔄 **跨进程一致**: 相同内容的对象在不同进程中产生相同哈希值
- 📦 **类型支持**: 支持基本类型、容器类型和自定义类型
- 🎯 **可扩展**: 通过类型注册机制支持自定义类型
- 💾 **智能缓存**: LRU缓存提升重复计算性能

## 安装

```bash
pip install pyhash-optimized
```

## 快速开始
```
python
from hashlib_optimized import my_hash

# 基本类型
print(my_hash("hello").hex())
print(my_hash(42).hex())

# 容器类型
data = {"users": [{"name": "Alice", "age": 30}, {"name": "Bob", "age": 25}]}
print(my_hash(data).hex())

# 一致性验证
assert my_hash([1, 2, 3]) == my_hash([1, 2, 3])
```
## 自定义类型支持
```
python
from hashlib_optimized import register_type
from datetime import datetime

@register_type(datetime)
def hash_datetime(obj):
    return obj.isoformat().encode()

# 或者实现协议
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    
    def __hash_bytes__(self):
        return f"Point({self.x},{self.y})".encode()
```

## 运行测试
```
bash
# 运行所有测试
pytest tests/

# 运行性能测试
python benchmarks/benchmark.py
python benchmarks/performance_tests.py
```

## 性能对比
与原始递归实现相比，优化版本提供：

2-5倍性能提升

无递归深度限制

更低的内存使用

